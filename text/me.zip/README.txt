This is a master/bachelor thesis template for students studying at Department of Mathematics and Information Technology of Saint-Petersburg Academic University.

Это шаблон дипломной или курсовой работы для студентов кафедры математических и информационных технологий СПбАУ РАН (Академического Университета).

=============================================================
Статус: добавлен Anton Kuznetsov, внесение изменений по требованию
Последние изменения: 29 мая 2015


